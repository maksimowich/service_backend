# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['vacancy_resume_backend']

package_data = \
{'': ['*']}

install_requires = \
['fastapi>=0.104.0,<0.105.0',
 'langchain==0.0.314',
 'openai==0.28.1',
 'pgvector>=0.2.3,<0.3.0',
 'psycopg2-binary>=2.9.9,<3.0.0',
 'python-docx>=1.1.0,<2.0.0',
 'python-multipart>=0.0.6,<0.0.7',
 'tiktoken>=0.5.1,<0.6.0',
 'uvicorn>=0.23.2,<0.24.0']

entry_points = \
{'console_scripts': ['start-backend = vacancy_resume_backend.main:main']}

setup_kwargs = {
    'name': 'vacancy-resume-backend',
    'version': '0.1.6',
    'description': '',
    'long_description': 'None',
    'author': 'Alexander',
    'author_email': 'cahr2001@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.1,<4.0.0',
}


setup(**setup_kwargs)
